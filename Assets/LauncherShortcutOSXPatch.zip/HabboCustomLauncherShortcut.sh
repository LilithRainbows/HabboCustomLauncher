#!/bin/bash

# Variables globales

RUTAABSOLUTA="%HabboCustomLauncherAppPath%"
NOMBRE="HabboCustomLauncher"


# Generador de bundle en Mac

## Es importante extraer en $HOME/Downloads tanto MainMenu.nib HabboCustomLauncherShortcut y el AppIcon.Icns antes de ejecutar el script o se detendra y removera el bundle ante errores

## moverse a Downloads para ejecutarse

cd $HOME/Downloads

## Revisa si existe el bundle, para borrarlo antes

if [ -d "/Applications/"$NOMBRE".app/" ]; then
rm -rf "/Applications/"$NOMBRE".app/"
fi

## Primero las carpetas

mkdir -p "/Applications/"$NOMBRE".app/Contents/Resources/"
mkdir -p "/Applications/"$NOMBRE".app/Contents/MacOS"

## Generar Info.plist

echo  '<?xml version="1.0" encoding="UTF-8"?> 
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"  
"http://www.apple.com/DTDs/PropertyList-1.0.dtd"> 
<plist version="1.0"> 
<dict> 
	<key>CFBundleDevelopmentRegion</key> 
	<string>en</string> 
	<key>CFBundleDisplayName</key> 
	<string>HabboCustomLauncherShortcut</string> 
	<key>CFBundleExecutable</key> 
	<string>HabboCustomLauncherShortcut</string> 
	<key>CFBundleIconFile</key> 
	<string>AppIcon.icns</string> 
	<key>CFBundleIdentifier</key> 
	<string>org.LilithRainbows.HabboCustomLauncher</string> 
	<key>CFBundleInfoDictionaryVersion</key> 
	<string>6.0</string> 
	<key>CFBundleName</key> 
	<string>HabboCustomLauncher</string> 
	<key>CFBundlePackageType</key> 
	<string>APPL</string> 
	<key>CFBundleShortVersionString</key> 
	<string>1.0</string>
	<key>CFBundleURLTypes</key> 
	<array>
		<dict>
			<key>CFBundleURLName</key>
			<string>org.LilithRainbows.HabboCustomLauncher</string> 
			<key>CFBundleURLSchemes</key>
				<array>
					<string>habbo</string> 
				</array>  
		</dict> 
	</array> 
	<key>LSMinimumSystemVersion</key> 
	<string>10.11.0</string> 
	<key>LSUIElement</key> 
	<false/> 
	<key>NSAppTransportSecurity</key> 
	<dict> 
		<key>NSAllowsArbitraryLoads</key> 
		<true/> 
	</dict> 
	<key>NSHumanReadableCopyright</key> 
	<string>LilithRainbows</string> 
	<key>NSMainNibFile</key> 
	<string>MainMenu</string> 
	<key>NSPrincipalClass</key>  
	<string>NSApplication</string> 
</dict> 
 </plist> 
' > "/Applications/"$NOMBRE".app/Contents/Info.plist"


## Mover HabboCustomLauncherShortcut a MacOs en el bundle, este deberia ir incrustado en la app, por favor extraer antes de ejecutar este script

if [ -f "HabboCustomLauncherShortcut" ]; then
	mv "HabboCustomLauncherShortcut" "/Applications/"$NOMBRE".app/Contents/MacOs/" 
else
	echo "HabboCustomLauncherShortcut file does not exist"
	rm -rf "/Applications/"$NOMBRE".app/"
	exit 1
fi

## De igual manera extraer el icono, que debe llamarse AppIcon.icns

if [ -f "AppIcon.icns" ]; then
        mv "AppIcon.icns" "/Applications/"$NOMBRE".app/Contents/Resources/"
else   
        echo "AppIcon.icns file does not exist"
	rm -rf "/Applications/"$NOMBRE".app/"
        exit 1
fi 

## Crear fichero AppSettings.plist

echo '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" 
"http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>AcceptsFiles</key>
	<false/>
	<key>AcceptsText</key>
	<false/>
	<key>Authentication</key>
	<false/>
	<key>Creator</key>
	<string>Platypus-5.4.1</string>
	<key>Droppable</key>
	<false/>
	<key>InterfaceType</key>
	<string>None</string>
	<key>InterpreterArgs</key>
	<array/>
	<key>InterpreterPath</key>
	<string>/bin/sh</string>
	<key>PromptForFileOnLaunch</key>
	<false/>
	<key>RemainRunning</key>
	<false/>
	<key>ScriptArgs</key>
	<array/>
	<key>SendNotifications</key>
	<false/>
	<key>Suffixes</key>
	<array/>
	<key>TextBackground</key>
	<string>#ffffff</string>
	<key>TextFont</key>
	<string>Monaco</string>
	<key>TextForeground</key>
	<string>#000000</string>
	<key>TextSize</key>
	<real>13</real>
	<key>URISchemes</key>
	<array/>
	<key>UniformTypes</key>
	<array>
		<string>public.item</string>
		<string>public.folder</string>
	</array>
</dict>
</plist>
' > "/Applications/"$NOMBRE".app/Contents/Resources/AppSettings.plist"

## MainMenu.nib debe extraerse primero y moverse

if [ -d "MainMenu.nib" ]; then
        mv "MainMenu.nib" "/Applications/"$NOMBRE".app/Contents/Resources/"
else
        echo "MainMenu.nib file does not exist"
	rm -rf "/Applications/"$NOMBRE".app/"
        exit 1
fi

## Crear script. Si existe antes lo borra y lo sobrescribe con una nueva ruta absoluta

if [ -f "/Applications/"$NOMBRE".app/Contents/Resources/script" ]; then
        rm "/Applications/"$NOMBRE".app/Contents/Resources/script"
fi

echo "#!/bin/bash" > "/Applications/"$NOMBRE".app/Contents/Resources/script"
echo "$RUTAABSOLUTA"' $1' >> "/Applications/"$NOMBRE".app/Contents/Resources/script"
chmod +x "/Applications/"$NOMBRE".app/Contents/Resources/script"
chmod +x "/Applications/"$NOMBRE".app/Contents/MacOS/HabboCustomLauncherShortcut"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "/Applications/"$NOMBRE".app"
