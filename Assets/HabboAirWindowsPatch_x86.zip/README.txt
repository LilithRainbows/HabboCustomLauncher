Instructions:
-Launch Habbo as executable 
-Enter the SSO ticket and press Enter

AIR SDK Version: 51.5.1