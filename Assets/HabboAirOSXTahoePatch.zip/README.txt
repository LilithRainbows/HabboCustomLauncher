Instructions:
-Launch Habbo as executable (located in Habbo.app/Contents/MacOS)
-Enter the SSO ticket and press Enter

AIR SDK Version: 51.3.1.1